-- DropIndex
DROP INDEX "experience_on_experts_experience_id_key";

-- DropIndex
DROP INDEX "skills_on_experts_exp_id_key";

-- DropIndex
DROP INDEX "skills_on_experts_skill_id_key";

-- DropIndex
DROP INDEX "status_on_experts_status_id_key";

-- DropIndex
DROP INDEX "work_mode_on_experts_work_mode_id_key";
